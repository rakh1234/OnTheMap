//
//  BaseStudentsViewController.swift
//  OnTheMapProject2
//
//  Created by Razan on 13/01/2021.
//
import UIKit
  
class BaseStudentsViewController: UIViewController {

    let parseStundentName: (StudentLocation) -> String = { studentLocation in
        "\(studentLocation.firstName) \(studentLocation.lastName)"
                .trimmingCharacters(in: .whitespaces)
    }

    var studentLocationList: [StudentLocation] = []

    private lazy var networkActivityAlert = self.showNetworkActivityAlert()

    private lazy var getStudentsListErrorMessage = """
                                                   Can't to download the students list location.
                                                   Please try again.
                                                   """
    private lazy var logoutErrorMessage = """
                                          Can't to complete the log out.
                                          Please try again.
                                          """

    func getStudentsList(successHandler: @escaping ([StudentLocation]) -> Void, reset: Bool) {
        guard let studentsURL = UdacityClient.Endpoint.getListOfStudentLocation.url else {
            print("Can't create URL")
            return
        }
        self.present(networkActivityAlert, animated: true, completion: nil)
        func handleSuccess() {
            self.studentLocationList = StudentRepository.sharedInstance.studentLocationList
            networkActivityAlert.dismiss(animated: false, completion: nil)
            successHandler(self.studentLocationList)
        }
        if (StudentRepository.sharedInstance.studentLocationList.count < 100 || reset) {

            UdacityClient.getStudentsDataTask(url: studentsURL,
                    successHandler: { studentLocationList in
                        DispatchQueue.main.async {
                            StudentRepository.sharedInstance.studentLocationList = studentLocationList
//                            self.networkActivityAlert.dismiss(animated: true, completion: nil)
//                            self.studentLocationList = StudentRepository.sharedInstance.studentLocationList
//                            successHandler(self.studentLocationList)
                            handleSuccess()
                        }
                    },
        errorHandler: { _ in self.networkActivityAlert.dismiss(animated: false, completion: {
                        self.showErrorAlert(message: self.getStudentsListErrorMessage)
                        })
                    })
          } else {
            handleSuccess()
        }
    }
    func segueToAddLocationVC() {
        self.performSegue(withIdentifier: "segueToAddLocatocation", sender: self)
    }

    func performLogout() {
        guard let logoutURL = UdacityClient.Endpoint.udacitySessionURL.url else {
            print("Can't create URL")
            return
        }

        self.view.window!.rootViewController?.dismiss(animated: true, completion: nil)
        let request = UdacityClient.deleteSessionRequest(url: logoutURL) 
        UdacityClient.executeDataTask(request: request,
                successHandler: { data in self.onLogoutSuccess() },
            errorHandler: { _ in self.networkActivityAlert.dismiss(animated: false, completion: {
                        self.showErrorAlert(message: self.logoutErrorMessage)
                    })
                })
         }
    private func onLogoutSuccess() {
        DispatchQueue.main.async {
            StudentRepository.sharedInstance.clear()
            self.segueOnLogoutSuccess()
        }
    }

    private func segueOnLogoutSuccess() {
        let homeViewController = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController
        self.view.window?.rootViewController = homeViewController
        self.view.window?.makeKeyAndVisible()
    }

    func openBroweserIfValidMediaURL(_ subtitle: String) {
        guard let mediaURL: URL = URL(string: subtitle) else {
            return
        }
        UIApplication.shared.open(mediaURL)
    }
}
