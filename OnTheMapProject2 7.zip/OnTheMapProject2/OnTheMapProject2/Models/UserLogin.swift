//
//  UserLogin.swift
//  OnTheMapProject2
//
//  Created by Razan on 13/01/2021.
//
import Foundation

struct UserLogin: Codable {
    let udacity: UserLoginBody
}
struct UserLoginBody: Codable {
    let username: String
    let password :String
}
