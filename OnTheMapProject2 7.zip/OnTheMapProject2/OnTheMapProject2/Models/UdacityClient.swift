//
//  UdacityClient.swift
//  OnTheMapProject2
//
//  Created by Razan on 13/01/2021.
//
import Foundation

class UdacityClient {

    enum Endpoint: String {
        case getListOfStudentLocation = "https://onthemap-api.udacity.com/v1/StudentLocation?limit=100?&order=-updatedAt"
        case udacitySessionURL = "https://onthemap-api.udacity.com/v1/session"
        case udacityUserDataURL = "https://onthemap-api.udacity.com/v1/users"
        case udacityPostUserLocationURL = "https://onthemap-api.udacity.com/v1/StudentLocation"

        var url: URL? {
            URL(string: self.rawValue)
        }
    }
    class func executeDataTask(request: URLRequest, successHandler: @escaping (Data) -> Void, errorHandler: @escaping (Error?) -> Void) {
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if error != nil { // Handle error…
                errorHandler(error)
                return
            }
            if let response = response as? HTTPURLResponse {
                if let newData = data { // Handle success...
                    let subData = newData.udacityData() /* subset response data! */
                    if (response.statusCode == 200) {
                        successHandler(subData)
                    } else {
                        let udacityError = handleUdacityError(subData)
                        errorHandler(udacityError)
                    }
                }
            }
        }
        task.resume()
    }

    class func getStudentsDataTask(url: URL, successHandler: @escaping ([StudentLocation]) -> Void, errorHandler: @escaping (Error?) -> Void) {

        let task = URLSession.shared.dataTask(with: url) {
            (data, response, error) in
            guard let data = data else {
                print("no data")
                return
            }
            let decoder = JSONDecoder()
            do {
                let studentLocationList = try decoder.decode(StudentList.self, from: data)
                successHandler(studentLocationList.results)
            } catch {
                errorHandler(error)
            }
        }
        task.resume()
    }
    
    fileprivate class func handleUdacityError(_ subData: Data) -> Error {
        do {
            let udacityError = try JSONDecoder().decode(UdacityError.self, from: subData)
            return udacityError
        } catch {
            return error
         }
    }

    class func initLoginRequest(url: URL, username: String, password: String) -> URLRequest {

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        do {
            let studentLocationList = try JSONEncoder().encode(
                UserLogin(udacity: UserLoginBody(
                            username: username, password: password
                         )
                    )
               )
            request.httpBody = studentLocationList

        } catch {
            print(error)
        }
        return request
    }

    class func deleteSessionRequest(url: URL) -> URLRequest {

        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"
        let sharedCookieStorage = HTTPCookieStorage.shared
        if let xsrfCookie = sharedCookieStorage.cookies?.filter({ $0.name == "XSRF-TOKEN" }).first {
            request.setValue(xsrfCookie.value, forHTTPHeaderField: "X-XSRF-TOKEN")
        }
        return request
    }

    class func onLoginSucessGetProfileDataTask(
            studentSession: StudentSession,
            successHandler: @escaping (StudentProfile) -> Void,
            errorHandler: @escaping (Error?) -> Void) {
        guard let udacityUserDataBaseURL = UdacityClient.Endpoint.udacityUserDataURL.url else {
            print("Cannot create URL")
            return
        }
        let request = URLRequest(url: udacityUserDataBaseURL.appendingPathComponent(studentSession.account.key))
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if error != nil {
                errorHandler(error)
                return
            }
            if let newData = data?.udacityData() /* subset response data! */ {
                print(String(data: newData, encoding: .utf8)!)
                let decoder = JSONDecoder()
                do {
                    let userData = try decoder.decode(PublicUserData.self, from: newData)

                    successHandler(StudentProfile(
                            firstName: userData.first_name, lastName: userData.last_name, uniqueKey: studentSession.account.key
                    ))
                } catch {
                    errorHandler(error)
                }
            }
        }
        task.resume()
    }

    class func postStudentLocationRequest(url: URL, studentProfile: StudentProfile, readyLocationState: ReadyLocationState, mediaURL: String) -> URLRequest {

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        do {
            let studentLocationList = try JSONEncoder().encode(
                    StudentLocation(objectId: nil,
                            uniqueKey: studentProfile.uniqueKey,
                            firstName: studentProfile.firstName,
                            lastName: studentProfile.lastName,
                            mapString: readyLocationState.address,
                            mediaURL: mediaURL,
                            latitude: readyLocationState.coordinates.latitude,
                            longitude: readyLocationState.coordinates.longitude,
                            createdAt: nil
                    )
            )
            request.httpBody = studentLocationList
        } catch {
            print(error)
        }
        return request
    }
}
fileprivate extension Data {
    func udacityData() -> Data {
        subdata(in: 5..<count)
    }
}
