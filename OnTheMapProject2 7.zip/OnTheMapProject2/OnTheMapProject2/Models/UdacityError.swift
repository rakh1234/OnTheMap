//
//  UdacityError.swift
//  OnTheMapProject2
//
//  Created by Razan on 13/01/2021.
//
import Foundation

class UdacityError: Codable, Error {
    let status: Int
    let error: String
}
