//
//  StudentList.swift
//  OnTheMapProject2
//
//  Created by Razan on 13/01/2021.
//
import Foundation

struct StudentList: Codable {
    let results: [StudentLocation]
}
