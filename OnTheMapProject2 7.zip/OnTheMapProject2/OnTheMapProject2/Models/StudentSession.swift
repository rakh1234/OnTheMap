//
//  StudentSession.swift
//  OnTheMapProject2
//
//  Created by Razan on 13/01/2021.
//
import Foundation

struct StudentSession: Codable {
    let account: Account
    let session : Session
}

struct Account: Codable {
    let registered: Bool
    let key: String
}

struct Session: Codable {
    let id: String
    let expiration: String
}

struct PublicUserData: Codable {
    
    let first_name: String
    let last_name : String
    
    enum CodingKeys: String, CodingKey {
        case first_name = "first_name"
        case last_name = "last_name"
    }
}

struct StudentProfile: Codable {
    let firstName: String
    let lastName :String
    let uniqueKey: String
}
